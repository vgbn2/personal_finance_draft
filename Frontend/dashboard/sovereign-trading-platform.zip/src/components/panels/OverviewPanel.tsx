import React, { useEffect, useState } from 'react';
import { cn } from '../../lib/utils';
import { MetricTileData } from '../../types';
import { Terminal, ShieldCheck, Activity, AlertTriangle } from 'lucide-react';

const METRICS: MetricTileData[] = [
  { label: 'Backend Status', value: 'C++ BINARY OK', status: 'cyan', subtext: 'Latency: 12ms' },
  { label: 'Validated Records', value: '1,459,203', status: 'green', subtext: 'OHLCV count' },
  { label: 'Active Signals', value: '14', status: 'violet', subtext: 'Confidence > 0.65' },
  { label: 'Stale Provider', value: 'KALSHI', status: 'amber', subtext: 'Lag > 15m' },
];

export function OverviewPanel() {
  const [logs, setLogs] = useState<string[]>([]);
  
  useEffect(() => {
    const lines = [
      '[SYS] Initializing Sovereign Kernel v1.4.2...',
      '[DATA] Hydrating local cache from snapshot...',
      '[DATA] Waterproof Check: Verified 145,000 blocks.',
      '[MODEL] CNN Window v0 loaded in VRAM.',
      '[INFERENCE] Generating path signatures for AAPL, TSLA...',
      '[OK] 2 new candidates identified.',
    ];
    
    let i = 0;
    const interval = setInterval(() => {
      if (i < lines.length) {
        setLogs(prev => [...prev, lines[i]]);
      }
      i++;
      if (i >= lines.length) clearInterval(interval);
    }, 800);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-6 animate-in slide-in-from-bottom-2 duration-300">
      
      {/* Metrics Row */}
      <div className="grid grid-cols-4 gap-4">
        {METRICS.map((metric, idx) => {
          const colorMap = {
            cyan: 'var(--color-brand-cyan)',
            green: 'var(--color-brand-green)',
            violet: 'var(--color-brand-violet)',
            amber: 'var(--color-brand-amber)',
            red: 'var(--color-brand-red)'
          };
          
          return (
            <div key={idx} className="bg-[var(--bg-secondary)] border border-[var(--border-subtle)] p-5 rounded-xl flex flex-col gap-1 relative overflow-hidden group hover:border-[var(--border-focus)] transition-colors shadow-sm">
              <div 
                className="absolute left-0 top-0 bottom-0 w-[3px]" 
                style={{ backgroundColor: colorMap[metric.status] }} 
              />
              <span className="text-xs font-medium text-[var(--text-muted)] uppercase tracking-wider">{metric.label}</span>
              <span className="font-mono text-xl text-[var(--text-main)] font-semibold tracking-tight">{metric.value}</span>
              {metric.subtext && (
                <span className="font-mono text-[10px] text-[var(--text-faint)]">{metric.subtext}</span>
              )}
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-12 gap-6 h-[400px]">
        {/* Terminal Card (65% ~ col-span-8) */}
        <div className="col-span-8 bg-slate-900 border border-slate-800 rounded-xl relative flex flex-col overflow-hidden shadow-sm">
          <div className="h-10 border-b border-slate-800 flex items-center px-5 gap-3 bg-slate-800/50 shrink-0">
             <Terminal className="w-4 h-4 text-[var(--color-brand-cyan)]" />
             <span className="font-mono text-[10px] text-slate-400 tracking-widest uppercase">Live Log Stream [VISIBILITY]</span>
             <div className="ml-auto w-2 h-2 rounded-full bg-[var(--color-brand-cyan)] animate-pulse shadow-[0_0_8px_var(--color-brand-cyan)]" />
          </div>
          <div className="flex-1 p-5 overflow-y-auto font-mono text-[11px] text-slate-300 space-y-1">
            {logs.map((log, i) => (
              <div key={i} className="flex gap-4">
                <span className="text-slate-500 shrink-0">[{new Date().toISOString().split('T')[1].slice(0, -1)}]</span>
                <span className={log?.includes('OK') ? 'text-[var(--color-brand-green)]' : 
                               log?.includes('WARN') ? 'text-[var(--color-brand-amber)]' : 
                               log?.includes('MODEL') ? 'text-[var(--color-brand-violet)]' : ''}>
                  {log}
                </span>
              </div>
            ))}
            <div className="w-2 h-4 bg-slate-500 animate-pulse mt-1 inline-block" />
          </div>
        </div>

        {/* Correlation Heatmap (35% ~ col-span-4) */}
        <div className="col-span-4 bg-[var(--bg-secondary)] border border-[var(--border-subtle)] rounded-xl flex flex-col shadow-sm">
          <div className="h-10 border-b border-[var(--border-subtle)] flex items-center px-5 shrink-0 bg-slate-50/50">
             <span className="font-heading text-xs font-bold uppercase tracking-wider text-[var(--text-main)]">Correlation Matrix</span>
          </div>
          <div className="flex-1 p-5 grid grid-cols-8 gap-1 container">
            {/* 8x8 dummy grid */}
            {Array.from({ length: 64 }).map((_, i) => {
              // generate a pseudo-random value from -1 to 1 for color
              const val = Math.sin(i * 13.5) * Math.cos(i * 7.1);
              // if < 0 -> red, if > 0 -> green
              const r = val < 0 ? Math.floor(Math.abs(val) * 255) : 243;
              const g = val > 0 ? Math.floor(Math.abs(val) * 200 + 55) : 244;
              const b = val < 0 ? Math.floor(Math.abs(val) * 255) : 246; // very naive mapping just for visuals
              
              const isDiag = (i % 8) === Math.floor(i / 8);
              const bg = isDiag ? 'var(--color-brand-green)' : `rgb(${r}, ${g}, ${b})`;
              const opacity = isDiag ? 1 : Math.max(0.1, Math.abs(val));

              return (
                <div 
                  key={i} 
                  className="w-full aspect-square relative group cursor-crosshair transition-opacity hover:opacity-100" 
                  style={{ backgroundColor: bg, opacity, borderRadius: '1px' }}
                >
                  <div className="absolute inset-0 hidden group-hover:flex items-center justify-center bg-black/80 font-mono text-[8px] text-white z-10 scale-150 rounded shadow-md pointer-events-none">
                    {val.toFixed(2)}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

    </div>
  );
}
