import React, { useState } from 'react';
import { TradeSignal } from '../../types';
import { cn } from '../../lib/utils';
import { Eye, ShieldAlert } from 'lucide-react';

const MOCK_SIGNALS: TradeSignal[] = [
  { id: 'S-1042', asset: 'AAPL', model: 'CNN Window v0', direction: 'SHORT', confidence: 0.82, status: 'GATED', timestamp: '2026-05-26T08:05:12Z', evidenceId: 'TENSOR-99A' },
  { id: 'S-1043', asset: 'NVDA', model: 'SVM Margin', direction: 'LONG', confidence: 0.91, status: 'GATED', timestamp: '2026-05-26T08:06:45Z', evidenceId: 'PATH-102B' },
  { id: 'S-1039', asset: 'TSLA', model: 'XGBoost Ranker', direction: 'SHORT', confidence: 0.45, status: 'REJECTED', timestamp: '2026-05-26T07:44:11Z', evidenceId: 'TREE-42' },
];

export function SignalPanel() {
  const [selectedIds, setSelectedIds] = useState<string[]>(['S-1042', 'S-1043']);
  const gatedCount = MOCK_SIGNALS.filter(s => s.status === 'GATED').length;

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  return (
    <div className="flex-1 overflow-y-auto flex flex-col bg-[var(--bg-primary)] animate-in slide-in-from-bottom-2 duration-300">
      
      <div className="p-6 pb-2">
        <h2 className="text-[32px] text-[var(--text-main)] mb-1">Candidate Signal Queue</h2>
        <p className="text-[var(--text-muted)] text-sm mb-6 max-w-2xl">
          Empirically verify path signatures before promoting to the executing matrix. Unverified models are permanently sandboxed.
        </p>
      </div>

      <div className="px-6 flex-1">
        <div className="bg-[var(--bg-secondary)] border border-[var(--border-subtle)] rounded-xl shadow-sm overflow-hidden">
          <table className="data-ledger">
            <thead>
              <tr>
                <th className="w-8">
                  <input type="checkbox" className="accent-[var(--color-brand-cyan)] rounded" />
                </th>
                <th>Asset</th>
                <th>Model</th>
                <th>Direction</th>
                <th className="w-48">Confidence</th>
                <th>Status</th>
                <th className="text-right">Evidence</th>
              </tr>
            </thead>
            <tbody>
              {MOCK_SIGNALS.map(signal => {
                const isSelected = selectedIds.includes(signal.id);
                return (
                  <tr key={signal.id} className={cn("hover:bg-[var(--bg-primary)] transition-colors group cursor-pointer", isSelected && "bg-[var(--bg-tertiary)]")}>
                    <td onClick={() => toggleSelect(signal.id)}>
                      <input 
                        type="checkbox" 
                        checked={isSelected} 
                        onChange={() => {}}
                        className="accent-[var(--color-brand-cyan)] rounded" 
                      />
                    </td>
                    <td className="font-bold flex flex-col group relative" title="H2V: Binance OHLCV, 5m lag">
                      <span className="border-b border-dashed border-gray-400 w-fit">{signal.asset}</span>
                      <span className="text-[9px] text-[var(--text-faint)] absolute -bottom-3 hidden group-hover:block whitespace-nowrap bg-[var(--bg-secondary)] border border-[var(--border-subtle)] px-1 rounded shadow-sm z-10 text-[var(--color-brand-green)]">
                        Waterproof: Verified
                      </span>
                    </td>
                    <td className="text-[var(--color-brand-violet)]">{signal.model}</td>
                    <td>
                      <span className={cn(
                        "px-1.5 py-0.5 rounded text-[10px] font-bold tracking-wider",
                        signal.direction === 'LONG' ? "bg-[var(--color-brand-green)]/10 text-[var(--color-brand-green)]" : "bg-[var(--color-brand-red)]/10 text-[var(--color-brand-red)]"
                      )}>
                        {signal.direction}
                      </span>
                    </td>
                    <td>
                      <div className="flex items-center gap-2">
                        <span className="block w-8 text-right">{(signal.confidence * 100).toFixed(0)}%</span>
                        <div className="flex-1 h-1 bg-[var(--bg-tertiary)] rounded overflow-hidden">
                          <div 
                            className="h-full bg-[var(--color-brand-violet)] transition-all" 
                            style={{ width: `${signal.confidence * 100}%` }} 
                          />
                        </div>
                      </div>
                    </td>
                    <td>
                      <span className={cn(
                        "px-2 py-0.5 rounded-full text-[10px] uppercase font-bold tracking-widest border",
                        signal.status === 'GATED' ? "border-[var(--color-brand-amber)] text-[var(--color-brand-amber)]" :
                        signal.status === 'REJECTED' ? "border-[var(--color-brand-red)] text-[var(--color-brand-red)] opacity-50" :
                        "border-[var(--color-brand-green)] text-[var(--color-brand-green)]"
                      )}>
                        {signal.status}
                      </span>
                    </td>
                    <td className="text-right">
                      <button className="inline-flex items-center justify-center gap-1.5 px-2 py-1 text-[10px] border border-[var(--border-focus)] rounded bg-white hover:bg-[var(--bg-tertiary)] hover:border-[var(--color-brand-cyan)] text-[var(--text-main)] transition-colors">
                        <Eye className="w-3 h-3 text-[var(--color-brand-cyan)]" />
                        [VIEW]
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Promotion Gate */}
      <div className="mt-auto bg-white border-t border-[var(--border-subtle)] p-4 flex items-center justify-between shrink-0 shadow-[0_-4px_12px_rgba(0,0,0,0.03)] z-10 px-6">
        <div className="flex items-center gap-3 text-sm">
          <ShieldAlert className="w-5 h-5 text-[var(--color-brand-amber)]" />
          <span className="font-heading font-bold">{gatedCount} Candidates Pending Review</span>
          <span className="text-[var(--text-muted)] ml-2 text-xs font-mono">({selectedIds.length} Selected)</span>
        </div>
        
        <button className={cn(
          "bg-[var(--color-brand-cyan)] hover:bg-opacity-90 text-white font-heading font-medium tracking-wide uppercase text-xs px-8 py-3 rounded shadow-md transition-all active:scale-95",
          selectedIds.length === 0 && "opacity-50 cursor-not-allowed grayscale"
        )}>
          [VERIFY & PROMOTE] (Hold 2s)
        </button>
      </div>

    </div>
  );
}
