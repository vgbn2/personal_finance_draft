import React from 'react';
import { Activity, Database, GitMerge, LayoutDashboard, LineChart, Server } from 'lucide-react';
import { TabId } from '../../types';
import { cn } from '../../lib/utils';

interface TopBarProps {
  activeTab: TabId;
  onTabChange: (tab: TabId) => void;
}

const TABS: { id: TabId; label: string; number: string; icon: React.ReactNode }[] = [
  { id: 'overview', label: 'Overview', number: '01', icon: <LayoutDashboard className="w-4 h-4" /> },
  { id: 'signals', label: 'Signals', number: '02', icon: <Activity className="w-4 h-4" /> },
  { id: 'market_intel', label: 'Market Intel', number: '03', icon: <LineChart className="w-4 h-4" /> },
  { id: 'backtest', label: 'Backtest Ledger', number: '04', icon: <GitMerge className="w-4 h-4" /> },
  { id: 'quote_health', label: 'Quote Health', number: '05', icon: <Database className="w-4 h-4" /> },
  { id: 'audit_log', label: 'Audit Log', number: '06', icon: <Server className="w-4 h-4" /> },
];

export function TopBar({ activeTab, onTabChange }: TopBarProps) {
  return (
    <header className="h-14 bg-[var(--bg-secondary)] border-b border-[var(--border-subtle)] flex items-center justify-between px-6 z-[1000] sticky top-0 shrink-0">
      {/* Brand Slot */}
      <div className="flex items-center gap-6">
        <div className="font-heading font-bold text-lg tracking-tight text-[var(--text-main)]">
          Sovereign <em className="not-italic text-[var(--color-brand-cyan)] font-normal">Research OS</em>
        </div>

        {/* Global Tab Navigation */}
        <nav className="flex items-center h-full">
          {TABS.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={cn(
                  "h-14 px-4 flex items-center gap-2 text-sm font-medium transition-colors border-b-2",
                  isActive
                    ? "border-[var(--color-brand-cyan)] text-[var(--color-brand-cyan)]"
                    : "border-transparent text-[var(--text-muted)] hover:text-[var(--text-main)] hover:bg-[var(--bg-tertiary)]"
                )}
              >
                <span className="font-mono text-xs opacity-60">[{tab.number}]</span>
                {tab.label}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Global Actions */}
      <div className="flex items-center gap-3">
        <button className="btn-ghost py-1.5 h-8">Ingest Snapshot</button>
        <button className="btn-primary py-1.5 h-8">Run Comparison</button>
        <div className="flex items-center gap-2 bg-[var(--bg-tertiary)] border border-[var(--border-subtle)] rounded-full px-3 py-1 h-8">
          <div className="w-2 h-2 rounded-full bg-[var(--color-brand-green)] shadow-[0_0_8px_var(--color-brand-green)] animate-pulse" />
          <span className="font-mono text-[10px] font-bold text-[var(--color-brand-green)] tracking-wider">LIVE</span>
        </div>
      </div>
    </header>
  );
}
